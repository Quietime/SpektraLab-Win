module.exports.isNode = false;

