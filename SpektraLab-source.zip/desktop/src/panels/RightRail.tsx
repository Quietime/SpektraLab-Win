// RightRail.tsx — "Parameters" (`Panels/RightPanel.swift`):
//   Pre-Dev:  Latitude · Input / Camera · Film Format · Scene Placement
//   Post-Dev: White Balance · Exposure · Curve · Color Balance (Layer 2)

import { useEffect, useRef, useState, useId } from 'react';
import { Checkbox, NumberField, PillMenu, ScrubSlider, Section, SegmentedSwitch, ToggleRow, signed } from '../controls/controls';
import { t, tz } from '../i18n';
import { hostRedecodes, setAdjustments, setDecode, setFilmFrame, setFilmSide, setParams, setSideLengthMM, useSession,editingAdjustments,setPicker,beginGesture } from '../state/session';
import { settingsStore, useSettings } from '../state/settings';
import {isMonochromeStock} from '@shared/stockRules';
import {
  type AEMethod,
  EFFECTS_DEFAULT,
  EFFECT_RANGES,
  FILM_FRAMES,
  FILM_FRAME_CUSTOM,
  SIDE_UNIT_DECIMALS,
  SIDE_UNIT_PER_MM,
  type SideUnit,
  aeMethodOf,
  applyAEMethod,
  SCENE_LATITUDE_DEFAULT,
} from '@shared/params';
import { type ColorZone, type CurveChannel, CURVE_CHANNELS, isNeutral } from '@shared/adjustments';
import {
  type AsShot,
  TEMPERATURE_RANGE,
  TINT_RANGE,
  WB_MODES,
  applyBoxes,
  boxesOf,
  isRawPath,
  modeOf,
  shownDecode,
  withPreset,
  withTemperature,
  withTint,
} from '@shared/whiteBalance';
import { CurveEditor } from './CurveEditor';
import { unsupportedReason } from './gate';
import { host, HostCallError } from '../host/client';
import { fitPlacement,placementWindow,type PlacementSide } from '@shared/placement';
import {latitudeReadout,type LatitudeReply} from '@shared/latitude';
import {arcTheta,arcValue,type WheelArc}from '@shared/colorWheel';

export function RightRail() {
  const tab = useSettings((s) => s.parametersTab);
  const edited = useSession((s) => editingAdjustments(s).enabled && !isNeutral(editingAdjustments(s)));
  const measurement=useLatitudeMeasurement();
  return (
    <aside className="rail right" data-testid="right-rail">
      <div className="rail-header">{t('railParameters')}</div>
      <SegmentedSwitch
        value={tab}
        onChange={(v) => settingsStore.getState().set('parametersTab', v)}
        options={[
          { value: 'preDev', label: t('tabPreDev') },
          { value: 'postDev', label: t('tabPostDev'), marked: edited, markHelp: tz('The grade is not neutral.', '调色不是中性的。') },
        ]}
      />
      <div className="hairline" />
      <div className="rail-scroll">
        {tab === 'preDev' ? (
          <>
            <LatitudeSection measurement={measurement} />
            <CameraSection />
            <FilmFormatSection />
            <ScenePlacementSection measurement={measurement} />
          </>
        ) : (
          <>
            <WhiteBalanceSection />
            <ExposureSection />
            <CurveSection />
            <ColorBalanceSection />
          </>
        )}
      </div>
    </aside>
  );
}

// ------------------------------------------------------------------ Latitude

function useLatitudeMeasurement() {
  const sid = useSession((s) => s.engineSession);
  const badge = useSession((s) => s.badge);
  const film = useSession((s) => s.sidecar.params.filmStock);
  const paper = useSession((s) => s.sidecar.params.printStock);
  const image=useSession(s=>s.imageVersion),side=useSession(s=>s.pairSide),pair=useSession(s=>s.pairInfo);
  const sl=useSession(s=>s.sidecar.params.sceneLatitude);
  const [reply, setReply] = useState<LatitudeReply | null>(null);
  const [measuredSession,setMeasuredSession]=useState<string|null>(null);
  const [why, setWhy] = useState<string | null>(null);
  useEffect(() => {
    if (!sid || badge !== 'full') return;
    let live = true;
    const t0 = setTimeout(() => {
      host()
        .sceneLatitude(sid, {highlight_pull_back:sl.highlightPullBack,shadow_pull_back:sl.shadowPullBack,
          rolloff:sl.rolloff,max_lift:sl.maxLift,norm:sl.norm,shadow_percentile:sl.shadowPercentile,highlight_percentile:sl.highlightPercentile,
          ...(pair?{region:(()=>{const r=pair.rects[side==='left'?0:1]!;return [r[0],r[1],r[0]!+r[2]!,r[1]!+r[3]!];})()}:{} )})
        .then((r) => {
          if (live) {
            setReply(r as unknown as LatitudeReply);
            setMeasuredSession(sid+side);
            setWhy(null);
          }
        })
        .catch((e) => {
          if (!live) return;
          setReply(null);
          setWhy(e instanceof HostCallError && (e.code === 'unsupported' || e.code === 'bad_request') ? unsupportedReason('scene_latitude_mapping', false) : String((e as Error).message));
        });
    }, 250);
    return () => {
      live = false;
      clearTimeout(t0);
    };
  }, [sid,badge,film,paper,image,side,pair,sl]);
  return {reply:measuredSession===sid+side?reply:null,why};
}
function LatitudeSection({measurement:{reply,why}}:{measurement:ReturnType<typeof useLatitudeMeasurement>}) {
  const film=useSession(s=>s.sidecar.params.filmStock),paper=useSession(s=>s.sidecar.params.printStock),catalog=useSession(s=>s.catalog);
  const name = (id: string) => catalog.stock(id)?.name.replace(/^(Kodak|Fujifilm) (Professional )?/, '') ?? id;
  return (
    <Section id="latitude" title={t('sectionLatitude')} trailing={`${name(film)} · ${name(paper)}`} unsupported={why}>
      <LatitudePlot reply={reply} />
    </Section>
  );
}

function LatitudePlot({ reply }: { reply: LatitudeReply | null }) {
  const W = 240;
  const H = 60;
  const id=useId();
  if (!reply) return <svg className="plot" viewBox={`0 0 ${W} 84`} height={84} />;
  const h = reply.scene.histogram;
  const readout=latitudeReadout(reply),f=readout.fractions;
  const peak = Math.max(...f.filter((_,i)=>Math.abs(readout.centres[i]!)<=8).map(Math.sqrt), 1e-9);
  const x = (ev: number) => ((ev+8)/16)*W;
  const n = f.length;
  let below = 0;
  let above = 0;
  let total = 0;
  f.forEach((v, i) => {
    const c = h.lo_ev + ((i + 0.5) * (h.hi_ev - h.lo_ev)) / n;
    total += v;
    if (c < reply.medium.shadow_ev) below += v;
    else if (c > reply.medium.highlight_ev) above += v;
  });
  const pct = (v: number) => ((v / (total || 1)) * 100).toFixed(1) + ' %';
  return (
    <>
      <svg className="plot" viewBox={`0 0 ${W} 84`} height={84} data-testid="latitude-plot">
        <defs><clipPath id={id+'-clip'}><rect width={W} height={H}/></clipPath>
          <linearGradient id={id+'-band'}>{Array.from({length:65},(_,i)=><stop key={i} offset={`${i/64*100}%`} stopColor="var(--text)" stopOpacity={.9*readout.strength(-8+i/4)}/>)}</linearGradient>
        </defs>
        <g clipPath={`url(#${id}-clip)`}>
        <rect width={W} height={H} fill="var(--plot)"/>
        {[-6,-4,-2,0,2,4,6].map(ev=><line key={ev} x1={x(ev)} x2={x(ev)} y2={H} stroke="var(--plot-grid)" strokeWidth={.5}/>)}
        {f.map((v, i) => (
          <rect key={i} x={x(h.lo_ev+i*(h.hi_ev-h.lo_ev)/n)} y={H-Math.sqrt(v)/peak*(H-4)} width={(h.hi_ev-h.lo_ev)/n/16*W} height={Math.sqrt(v)/peak*(H-4)}
            fill={readout.centres[i]!<reply.medium.shadow_ev||readout.centres[i]!>reply.medium.highlight_ev?'var(--latitude-beyond)':'var(--latitude-inside)'}/>
        ))}
        </g>
        <rect y={64} width={W} height={6} rx={3} fill={`url(#${id}-band)`} data-testid="latitude-separation"/>
        {[reply.medium.shadow_ev,reply.medium.highlight_ev].filter(ev=>Math.abs(ev)<=8).map((ev,i)=><g key={i}>
          <line x1={x(ev)} x2={x(ev)} y1={1} y2={70} stroke="var(--secondary-text)" strokeWidth={.75} strokeDasharray="2 1.5"/>
          <text x={Math.max(2,Math.min(W-2,x(ev)+(i?3:-3)))} y={9} textAnchor={i?'start':'end'} fill="var(--secondary-text)" fontSize={8}>{ev.toFixed(2)}</text>
        </g>)}
        {[-8,-6,-4,-2,0,2,4,6,8].map(ev=><text key={ev} x={x(ev)} y={81} textAnchor={ev===-8?'start':ev===8?'end':'middle'} fill="var(--secondary-text)" fontSize={8}>{ev>0?'+':''}{ev}</text>)}
      </svg>
      <div className="caption num">
        {t('latitudeBelow')} {pct(below)} · {t('latitudeWithin')} {pct(total - below - above)} · {t('latitudeAbove')} {pct(above)} · {reply.medium.latitude_stops.toFixed(2)} {t('latitudeHeld')}
      </div>
      {readout.core&&<div className="caption num">{tz('Full separation','完整层次')} {readout.core[0].toFixed(2)} – {readout.core[1].toFixed(2)}</div>}
    </>
  );
}

// -------------------------------------------------------------------- Camera

function CameraSection() {
  const p = useSession((s) => s.sidecar.params);
  const paired=useSession(s=>!!s.pairDocument);
  const canPick=useSession(s=>!s.pairDocument&&s.frameKind==='raw'&&!s.sidecar.params.filmEdge.active&&s.hello?.methods?.includes('neutral_point')===true);
  const picking=useSession(s=>s.picker==='whiteBalance');
  const lens=useSession(s=>s.sidecar.decode.lensCorrection);
  const lensProfile=useSession(s=>s.metadata?.lens_profile);
  const lensSupported=useSession(s=>s.hello?.capabilities?.backend?.lens_profiles===true);
  const vignette = useSession((s) => editingAdjustments(s).vignette.amount);
  const ae = aeMethodOf(p);
  const lensReason = tz(
    'No measured lens profile matches this RAW photograph.',
    '这张 RAW 照片没有匹配的实测镜头配置。',
  );
  const wb = useWhiteBalance();
  const options: { value: AEMethod; label: string }[] = [
    { value: 'custom', label: t('meteringCustom') },
    { value: 'balanced', label: t('meteringBalanced') },
    { value: 'center', label: t('meteringCenter') },
    { value: 'protect_highlights', label: t('meteringProtectHighlights') },
    { value: 'protect_shadows', label: t('meteringProtectShadows') },
  ];
  if (ae === 'legacy') options.push({ value: 'legacy', label: t('meteringCenterWeightedLegacy') });
  const asShot = !p.autoExposure && p.exposureCompensationEV === 0;
  return (
    <Section
      id="camera"
      title={t('sectionCamera')}
      onReset={() => setParams((q) => ({ ...q, exposureCompensationEV: 0 }))}
      resetHelp={t('helpResetFilmExposure')}
      menu={[
        { label: t('helpResetFilmExposure'), onSelect: () => setParams((q) => ({ ...q, exposureCompensationEV: 0 })) },
        {label:tz('Pick neutral white balance','拾取中性白平衡'),checked:picking,disabled:!canPick,onSelect:()=>setPicker('whiteBalance')},
        // The presets keep their English names, as on the Mac.
        ...WB_MODES.filter((m) => m !== 'Custom').map((m) => ({
          label: `${t('helpWhiteBalancePreset')}: ${m}`,
          checked: wb.mode === m,
          disabled: !!wb.reason,
          onSelect: () => setDecode((d) => withPreset(d, wb.asShot, m)),
        })),
      ]}
    >
      {paired&&<div className="caption">{tz('Set RAW white balance and exposure separately in Half-frame Pair.','请在左侧「半格配对」中分别设置各孔 RAW 白平衡和曝光。')}</div>}
      <PillMenu label={t('cameraMetering')} value={ae} options={options} fill disabled={paired} onChange={(v) => setParams((q) => applyAEMethod(q, v))} testId="metering" />
      <ScrubSlider
        label={t('cameraFilmExposure')}
        sublabel={
          <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
            {t('cameraFilmExposureAsShot')}
            <Checkbox on={asShot} disabled={paired} label={t('cameraFilmExposureAsShot')} onChange={() => setParams((q) => ({ ...applyAEMethod(q, 'custom'), exposureCompensationEV: 0 }))} />
          </span>
        }
        value={p.exposureCompensationEV}
        range={[-3, 3]}
        snap={1 / 3}
        format={signed(1)}
        onChange={(v) => setParams((q) => ({ ...q, exposureCompensationEV: v }))}
        testId="film-exposure"
      />
      <ScrubSlider
        label={t('cameraTemperature')}
        sublabel={<AsShotLine on={wb.boxes.temp} enabled={!!wb.asShot && !wb.reason} onChange={(v) => setDecode((d) => applyBoxes(d, wb.asShot, { temp: v }))} />}
        value={wb.shown.temperature}
        range={TEMPERATURE_RANGE}
        zero={wb.asShot?.temperature ?? 5500}
        snap={100}
        format={(v) => v.toFixed(0)}
        onChange={(v) => setDecode((d) => withTemperature(d, wb.asShot, v))}
        disabled={!!wb.reason}
        reason={wb.reason ?? undefined}
        gradient="linear-gradient(90deg,#005982,#8FA83C,#FFF100)"
        testId="wb-temperature"
      />
      <ScrubSlider
        label={t('cameraTint')}
        sublabel={<AsShotLine on={wb.boxes.tint} enabled={!!wb.asShot && !wb.reason} onChange={(v) => setDecode((d) => applyBoxes(d, wb.asShot, { tint: v }))} />}
        value={wb.shown.tint}
        range={TINT_RANGE}
        zero={wb.asShot?.tint ?? 0}
        snap={5}
        format={signed(1)}
        onChange={(v) => setDecode((d) => withTint(d, wb.asShot, v))}
        disabled={!!wb.reason}
        reason={wb.reason ?? undefined}
        gradient="linear-gradient(90deg,#00A93A,#8AA45E,#E4007F)"
        testId="wb-tint"
      />
      <ScrubSlider label={t('cameraVignetting')} value={vignette} range={[-100, 100]} snap={5} format={signed(0)} onChange={(v) => setAdjustments((a) => ({ ...a, vignette: { ...a.vignette, amount: v } }))} />
      <ToggleRow label={t('cameraLensCorrection')} on={lens} onChange={v=>setDecode(d=>({...d,lensCorrection:v}))}
        disabled={paired||!lensSupported||(!lensProfile&&!lens)} reason={lensReason} />
      {lensProfile&&<div className="caption">{lensProfile}</div>}
    </Section>
  );
}

/** "As Shot ☐" — the second line under Temperature and Tint (`AsShotLine`). */
function AsShotLine({ on, enabled, onChange }: { on: boolean; enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
      {t('cameraFilmExposureAsShot')}
      <Checkbox on={on} label={t('cameraFilmExposureAsShot')} disabled={!enabled} onChange={onChange} />
    </span>
  );
}

/**
 * The decode white balance as the rows read it (`WhiteBalanceRows.swift`):
 * RAW only, and only on a host that can re-decode (R2's `redecode`).
 */
function useWhiteBalance() {
  const decode = useSession((s) => s.sidecar.decode);
  const shot = useSession((s) => s.metadata?.as_shot);
  const selection = useSession((s) => s.selection);
  const kind = useSession((s) => s.frameKind);
  const methods = useSession((s) => s.hello?.methods);
  const asShot: AsShot | null = shot ? { temperature: shot.temperature_k, tint: shot.tint } : null;
  const isRaw = kind ? kind === 'raw' : !!selection && isRawPath(selection);
  let reason: string | null = null;
  if (selection && !isRaw) reason = t('reasonDecodeWBDisabled');
  else if (!hostRedecodes(methods))
    reason = tz('This engine host cannot change white balance at decode (it has no `redecode`).', '此引擎进程不能在解码时更改白平衡（没有 `redecode`）。');
  return { mode: modeOf(decode), shown: shownDecode(decode, asShot), boxes: boxesOf(decode, asShot), asShot, reason };
}

// --------------------------------------------------------------- Film Format

function FilmFormatSection() {
  const p = useSession((s) => s.sidecar.params);
  const unit = useSettings((s) => s.sideUnit);
  const decouple = useSettings((s) => s.decoupleEffects);
  const isCustom = p.filmFrame === FILM_FRAME_CUSTOM.id;
  const e = p.effects;
  const setE = (patch: Partial<typeof e>) => setParams((q) => ({ ...q, effects: { ...q.effects, ...patch } }));
  const strength = (label: string, key: 'grain' | 'halation' | 'scatter' | 'couplers' | 'glare', enabled: boolean) => (
    <ScrubSlider label={label} value={e[key]} range={[...EFFECT_RANGES[key]] as [number, number]} zero={1} snap={0.25} format={(v) => v.toFixed(2)} disabled={!enabled} reason={t('reasonEffectOff')} onChange={(v) => setE({ [key]: v })} />
  );
  return (
    <Section
      id="filmFormat"
      title={t('filmFormat')}
      onReset={() => {
        setFilmFrame('135');
        setFilmSide('short');
        setParams((q) => ({ ...q, grainActive: true, halationActive: true, glareActive: true, effects: EFFECTS_DEFAULT }));
      }}
      resetHelp={t('helpResetFilmFormat')}
      menu={[
        { label: t('helpAllEffectsOn'), onSelect: () => setParams((q) => ({ ...q, grainActive: true, halationActive: true, glareActive: true })) },
        { label: t('helpAllEffectsOff'), onSelect: () => setParams((q) => ({ ...q, grainActive: false, halationActive: false, glareActive: false })) },
        { label: t('helpResetEffectStrengths'), onSelect: () => setParams((q) => ({ ...q, effects: EFFECTS_DEFAULT })) },
        { label: t('helpSubLayerGrain'), checked: e.grainLayered&&!isMonochromeStock(p.filmStock), disabled: !p.grainActive||isMonochromeStock(p.filmStock), onSelect: () => setE({ grainLayered: !e.grainLayered }) },
      ]}
    >
      <PillMenu
        label={t('filmFormatSize')}
        value={p.filmFrame}
        options={FILM_FRAMES.map((f) => ({ value: f.id, label: f.id, badge: f.isCine ? 'CINE' : undefined }))}
        onChange={(v) => setFilmFrame(v)}
        testId="film-format-size"
      />
      <PillMenu
        label={t('filmFormatSide')}
        value={p.filmSide}
        options={[
          { value: 'short', label: t('filmFormatShort') },
          { value: 'long', label: t('filmFormatLong') },
        ]}
        onChange={(v) => setFilmSide(v)}
      />
      <div className="row" title={isCustom ? undefined : t('reasonNonCustomSideLength')}>
        <span className="row-label">{t('filmFormatSideLength')}</span>
        <NumberField
          value={p.sideLengthMM / SIDE_UNIT_PER_MM[unit]}
          decimals={SIDE_UNIT_DECIMALS[unit]}
          label={t('filmFormatSideLength')}
          onCommit={(v) => setSideLengthMM(v * SIDE_UNIT_PER_MM[unit])}
        />
        <PillMenu<SideUnit>
          value={unit}
          options={[
            { value: 'mm', label: 'mm' },
            { value: 'cm', label: 'cm' },
            { value: 'inch', label: 'inch' },
          ]}
          onChange={(v) => settingsStore.getState().set('sideUnit', v)}
        />
      </div>
      <ToggleRow label={t('filmGrain')} on={p.grainActive} onChange={(v) => setParams((q) => ({ ...q, grainActive: v }))} testId="grain-toggle" />
      {decouple && strength(t('filmGrainStrength'), 'grain', p.grainActive)}
      <ToggleRow label={t('filmHalation')} on={p.halationActive} onChange={(v) => setParams((q) => ({ ...q, halationActive: v }))} />
      <ToggleRow label={t('filmAntihalationLayer')} on={!e.antihalationRemoved} disabled={!p.halationActive} reason={t('reasonEffectOff')} onChange={(v) => setE({ antihalationRemoved: !v })} />
      {decouple && (
        <>
          {strength(t('filmHalationStrength'), 'halation', p.halationActive)}
          {strength(t('filmScatterStrength'), 'scatter', p.halationActive)}
          <ScrubSlider label={t('filmHighlightBoost')} value={e.highlightBoost} range={[0, 8]} snap={0.5} format={(v) => v.toFixed(1)} disabled={!p.halationActive} onChange={(v) => setE({ highlightBoost: v })} />
          <ToggleRow label={t('filmCouplers')} on={e.couplersActive} onChange={(v) => setE({ couplersActive: v })} />
          {strength(t('filmCouplersStrength'), 'couplers', e.couplersActive)}
        </>
      )}
      <ToggleRow label={t('filmGlare')} on={p.glareActive} disabled={!p.printEffects} reason={t('reasonPrintEffectsOff')} onChange={(v) => setParams((q) => ({ ...q, glareActive: v }))} />
      {decouple && strength(t('filmGlareStrength'), 'glare', p.glareActive && p.printEffects)}
    </Section>
  );
}

// ----------------------------------------------------------- Scene Placement

function ScenePlacementSection({measurement}:{measurement:ReturnType<typeof useLatitudeMeasurement>}) {
  const gate = useSession((s) => s.gate);
  const sl = useSession((s) => s.sidecar.params.sceneLatitude);
  const [refusal,setRefusal]=useState<string|null>(null);
  const reason = unsupportedReason('scene_latitude_mapping', gate.sceneLatitude)??measurement.why;
  const measured=measurement.reply?.fit;
  const place=(side:PlacementSide,v:number)=>{
    if(!measured)return;
    const other=side==='highlight'?sl.shadowPullBack:sl.highlightPullBack;
    const window=placementWindow(measured,side,other,sl);
    const landed=v>0?(window?Math.min(window[1],Math.max(window[0],v)):0):0;
    const fit=fitPlacement(measured,side==='highlight'?landed:other,side==='shadow'?landed:other,sl);
    setRefusal(fit.issue?fit.issue.code:landed!==v?tz('The slider stopped at the range this frame can fit.','滑块停在这张照片可用的回拉范围。'):null);
    if(fit.value)setParams(p=>({...p,sceneLatitude:fit.value!}));
  };
  return (
    <Section id="scenePlacement" title={t('sectionScenePlacement')} unsupported={reason} onReset={() => {setParams(p=>({...p,sceneLatitude:{...SCENE_LATITUDE_DEFAULT}}));setRefusal(null);}} resetHelp={t('helpResetPlacement')} resetEnabled={sl.active}>
      <ScrubSlider label={t('placementHighlight')} value={sl.highlightPullBack} range={[0, 8]} snap={0.25} onChange={v=>place('highlight',v)} disabled={!!reason||!measured} reason={reason ?? tz('Waiting for measurement.','等待测量。')} testId="placement-highlight"/>
      <ScrubSlider label={t('placementShadow')} value={sl.shadowPullBack} range={[0, 8]} snap={0.25} onChange={v=>place('shadow',v)} disabled={!!reason||!measured} reason={reason ?? tz('Waiting for measurement.','等待测量。')} testId="placement-shadow"/>
      {refusal&&<div className="caption">{refusal}</div>}
    </Section>
  );
}

// ---------------------------------------------------------------- Post-Dev

function WhiteBalanceSection() {
  const a = useSession(editingAdjustments);
  return (
    <Section id="wb2" title={t('sectionWhiteBalance')} trailing={t('statusRightRailWBScope')} onReset={() => setAdjustments((q) => ({ ...q, temperature: 0, tint: 0 }))} resetHelp={t('helpReset')}>
      <ScrubSlider label={t('cameraTemperature')} value={a.temperature} range={[-100, 100]} snap={5} format={signed(0)} gradient="linear-gradient(90deg,#5d7de8,#bbb,#e8c04e)" onChange={(v) => setAdjustments((q) => ({ ...q, temperature: v }))} />
      <ScrubSlider label={t('cameraTint')} value={a.tint} range={[-100, 100]} snap={5} format={signed(0)} gradient="linear-gradient(90deg,#62c462,#bbb,#d05bd0)" onChange={(v) => setAdjustments((q) => ({ ...q, tint: v }))} />
    </Section>
  );
}

function ExposureSection() {
  const a = useSession(editingAdjustments);
  const row = (label: string, key: 'exposure' | 'contrast' | 'brightness' | 'saturation' | 'highlights' | 'shadows' | 'blackPoint' | 'whitePoint', range: [number, number], digits: number, snap: number) => (
    <ScrubSlider key={key} label={label} value={a[key]} range={range} snap={snap} format={signed(digits)} onChange={(v) => setAdjustments((q) => ({ ...q, [key]: v }))} testId={'adj-' + key} />
  );
  return (
    <Section
      id="exposure2"
      title={t('sectionExposure')}
      onReset={() => setAdjustments((q) => ({ ...q, exposure: 0, contrast: 0, brightness: 0, saturation: 0, highlights: 0, shadows: 0, blackPoint: 0, whitePoint: 0 }))}
      resetHelp={t('helpReset')}
    >
      {row(t('clipExposure'), 'exposure', [-3, 3], 2, 1 / 3)}
      {row(t('exposureContrast'), 'contrast', [-50, 50], 0, 5)}
      {row(t('exposureBrightness'), 'brightness', [-50, 50], 0, 5)}
      {row(t('exposureSaturation'), 'saturation', [-100, 100], 0, 5)}
      {row(t('exposureHighlights'), 'highlights', [-100, 100], 0, 5)}
      {row(t('exposureShadows'), 'shadows', [-100, 100], 0, 5)}
      {row(t('exposureBlackPoint'), 'blackPoint', [0, 50], 0, 1)}
      {row(t('exposureWhitePoint'), 'whitePoint', [0, 50], 0, 1)}
    </Section>
  );
}

const CHANNEL_LABEL: Record<CurveChannel, () => string> = {
  rgb: () => 'RGB',
  luma: () => t('curveLuma'),
  red: () => t('curveRed'),
  green: () => t('curveGreen'),
  blue: () => t('curveBlue'),
};

function CurveSection() {
  const [ch, setCh] = useState<CurveChannel>('rgb');
  const picking=useSession(s=>s.picker==='curve');
  const canPick=useSession(s=>!!s.selection&&!s.batchExporting);
  return (
    <Section
      id="curve"
      title={t('sectionCurve')}
      onReset={() => setAdjustments((q) => ({ ...q, curves: { ...q.curves, [ch]: { points: [[0, 0], [1, 1]] } } }))}
      resetHelp={t('helpReset')}
      menu={[{ label: t('helpResetChannels'), onSelect: () => setAdjustments((q) => ({ ...q, curves: { rgb: { points: [[0, 0], [1, 1]] }, luma: { points: [[0, 0], [1, 1]] }, red: { points: [[0, 0], [1, 1]] }, green: { points: [[0, 0], [1, 1]] }, blue: { points: [[0, 0], [1, 1]] } } })) }]}
    >
      <div className="row" style={{ gap: 4 }}>
        {CURVE_CHANNELS.map((c) => (
          <button key={c} className={'btn' + (c === ch ? ' primary' : '')} style={{ height: 18, padding: '0 8px', fontSize: 'var(--fs-small)' }} onClick={() => setCh(c)}>
            {CHANNEL_LABEL[c]()}
          </button>
        ))}
      </div>
      <CurveEditor channel={ch} />
      <button className={'btn'+(picking?' primary':'')} disabled={!canPick} onClick={()=>setPicker('curve')} data-testid="curve-picker">
        {tz('Pick a tone from the photograph','从照片拾取曲线色调')}
      </button>
    </Section>
  );
}

const ZONES: { key: 'master' | 'shadows' | 'midtones' | 'highlights'; label: () => string }[] = [
  { key: 'master', label: () => tz('Master', '整体') },
  { key: 'shadows', label: () => t('exposureShadows') },
  { key: 'midtones', label: () => t('balanceMidtones') },
  { key: 'highlights', label: () => t('exposureHighlights') },
];

function ColorBalanceSection() {
  const cb = useSession((s) => editingAdjustments(s).colorBalance);
  const [zone, setZone] = useState<(typeof ZONES)[number]['key']|'threeWay'>('master');
  const z = cb[zone==='threeWay'?'master':zone];
  const setAt=(key:(typeof ZONES)[number]['key'],patch:Partial<ColorZone>,coalesce=false)=>setAdjustments(q=>({...q,colorBalance:{...q.colorBalance,[key]:{...q.colorBalance[key],...patch}}}),{coalesce});
  const setZ = (patch: Partial<ColorZone>,coalesce=false) => setAt(zone==='threeWay'?'master':zone,patch,coalesce);
  return (
    <Section
      id="colorbalance"
      title={t('sectionColorBalance')}
      onReset={() => setAdjustments((q) => ({ ...q, colorBalance: { master: zero, shadows: zero, midtones: zero, highlights: zero } }))}
      resetHelp={t('helpReset')}
    >
      <div className="tabs" style={{gap:2}}>
        {[ZONES[0]!,{key:'threeWay' as const,label:()=> '3-Way'},...ZONES.slice(1)].map((zz) => (
          <button key={zz.key} className={zz.key === zone ? 'on' : ''} style={{flex:1,padding:'0 2px',fontSize:'var(--fs-small)'}} onClick={() => setZone(zz.key)}>
            {zz.label()}
          </button>
        ))}
      </div>
      {zone==='threeWay'?<div data-testid="three-way-wheels">
        <div style={{textAlign:'center'}}>{ZONES[2]!.label()}<HueWheel zone={cb.midtones} onChange={(p,c)=>setAt('midtones',p,c)} size={120}/></div>
        <div style={{display:'flex',justifyContent:'space-around'}}>
          {(['shadows','highlights']as const).map(key=><div key={key} style={{textAlign:'center'}}>{key==='shadows'?ZONES[1]!.label():ZONES[3]!.label()}<HueWheel zone={cb[key]} onChange={(p,c)=>setAt(key,p,c)} size={104}/></div>)}
        </div>
      </div>:<>
      <HueWheel zone={z} onChange={setZ} />
      <ScrubSlider label={tz('Hue', '色相')} value={z.hue} range={[0, 360]} snap={15} format={(v) => v.toFixed(0) + '°'} gradient="linear-gradient(90deg,#e8524e,#e8c04e,#62c462,#4ec0e8,#5d7de8,#d05bd0,#e8524e)" onChange={(v) => setZ({ hue: v })} />
      <ScrubSlider label={t('exposureSaturation')} value={z.saturation} range={[0, 1]} snap={0.05} onChange={(v) => setZ({ saturation: v })} />
      <ScrubSlider label={tz('Luminance', '亮度')} value={z.luminance} range={[-1, 1]} snap={0.05} format={signed(2)} onChange={(v) => setZ({ luminance: v })} />
      </>}
    </Section>
  );
}
const zero: ColorZone = { hue: 0, saturation: 0, luminance: 0 };

/** The Mac disc and its two 130-degree arc controls. Coordinates are mapped
 * through the SVG view box, so interface scaling cannot change a value. */
function HueWheel({ zone, onChange,size=138 }: { zone: ColorZone; onChange: (z: Partial<ColorZone>,coalesce?:boolean) => void;size?:number }) {
  const ref = useRef<SVGSVGElement>(null);
  const active=useRef<'disc'|WheelArc|null>(null),lastPart=useRef<'disc'|WheelArc|null>(null),id=useId();
  const R = 46;
  const set = (e: React.PointerEvent) => {
    const r = ref.current!.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2))*128/r.width;
    const dy = (e.clientY - (r.top + r.height / 2))*128/r.height;
    const sat = Math.min(1, Math.hypot(dx, dy) / (R-5));
    const hue = ((Math.atan2(-dy, dx) * 180) / Math.PI + 360) % 360;
    if(active.current==='disc')onChange({ hue, saturation: sat },true);
    else if(active.current)onChange({[active.current]:arcValue(hue,active.current)},true);
  };
  const a = (zone.hue * Math.PI) / 180;
  const point=(fraction:number,side:WheelArc,radius=55)=>{const angle=arcTheta(fraction,side)*Math.PI/180;return [radius*Math.cos(angle),-radius*Math.sin(angle)];};
  const part=(target:EventTarget)=>(target as Element).closest('[data-wheel-part]')?.getAttribute('data-wheel-part')as 'disc'|WheelArc|null;
  return (
    <div className="row" style={{ justifyContent: 'center' }}>
      <svg
        ref={ref}
        width={size} height={size} viewBox="-64 -64 128 128" data-testid="color-wheel"
        onPointerDown={(e) => {
          const p=part(e.target);lastPart.current=p;if(!p)return;active.current=p;beginGesture();
          e.currentTarget.setPointerCapture(e.pointerId);
          set(e);
        }}
        onPointerMove={(e) => e.buttons&&active.current&&set(e)}
        onPointerUp={()=>{active.current=null;}}
        onPointerCancel={()=>{active.current=null;}}
        onDoubleClick={e=>{const p=part(e.target)??lastPart.current;if(p==='disc')onChange(zero);else if(p)onChange({[p]:0});}}
        style={{ cursor: 'crosshair',touchAction:'none' }}
      >
        <defs>
          <radialGradient id={id+'-fade'}>
            <stop offset="0" stopColor="var(--card)" stopOpacity="1" />
            <stop offset="1" stopColor="var(--card)" stopOpacity="0" />
          </radialGradient>
        </defs>
        {(['saturation','luminance']as const).map(side=>{
          const p=point(0,side),q=point(1,side),fraction=side==='saturation'?zone.saturation:(zone.luminance+1)/2;
          const inner=point(fraction,side,51),outer=point(fraction,side,59);
          return <g key={side} data-wheel-part={side}>
            <path d={`M${p.join(' ')} A55 55 0 0 ${side==='saturation'?1:0} ${q.join(' ')}`} fill="none" stroke={side==='saturation'?`hsl(${zone.hue} 55% 50%)`:'var(--secondary-text)'} strokeWidth={2}/>
            <path d={`M${p.join(' ')} A55 55 0 0 ${side==='saturation'?1:0} ${q.join(' ')}`} fill="none" stroke="transparent" strokeWidth={12} strokeLinecap="round"/>
            <line x1={inner[0]} y1={inner[1]} x2={outer[0]} y2={outer[1]} stroke="var(--knob)" strokeWidth={2}/>
          </g>;
        })}
        <g data-wheel-part="disc">
        {Array.from({ length: 36 }, (_, i) => {
          const a0 = (i * 10 * Math.PI) / 180;
          const a1 = ((i + 1) * 10 * Math.PI) / 180;
          return <path key={i} d={`M0 0 L${R * Math.cos(a0)} ${-R * Math.sin(a0)} A${R} ${R} 0 0 0 ${R * Math.cos(a1)} ${-R * Math.sin(a1)} Z`} fill={`hsl(${i * 10 + 5} 55% 50%)`} />;
        })}
        <circle r={R} fill={`url(#${id}-fade)`} />
        <circle cx={zone.saturation * (R-5) * Math.cos(a)} cy={-zone.saturation * (R-5) * Math.sin(a)} r={4} fill="var(--knob)" stroke="var(--card)" strokeWidth={1} />
        </g>
      </svg>
    </div>
  );
}
