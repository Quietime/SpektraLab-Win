# SpektraLab host protocol (Linux / Windows desktop)

The Linux/Windows desktop app is two processes:

- **`spektralab-host`** (`engine/host/`, C++20): owns the engine (`spk_*` C ABI,
  Vulkan backend), RAW decode (LibRaw), raster decode, and file writing.
- **The TypeScript app** (`desktop/`, Tauri 2): the interface. The Tauri core
  (Rust) spawns the host as a sidecar and relays messages to the webview.

A process boundary instead of an in-process addon is deliberate: a GPU driver
fault takes down the host, not the window holding the user's edits; the host
cross-compiles with MinGW without any Rust/webview ABI; and the frontend can
restart a dead host and re-open the frame from its sidecar.

This file is the contract between `engine/host/` and `desktop/`. **Changes are
additive** (new methods, new optional fields). A breaking change bumps
`protocol` in `hello` and edits this file in the same commit.

---

## 1. Transport

`spektralab-host --resources <engine-resources-dir> [--device <index>] [--log-level info]`

stdin/stdout carry binary frames; stderr is a free-form log (one line per entry).

Every frame, in both directions:

```
u32 LE  header_len      (bytes of UTF-8 JSON that follow)
u32 LE  payload_len     (bytes of binary payload after the JSON; may be 0)
u8[header_len]  JSON header
u8[payload_len] binary payload
```

- Request:  `{"id": <u32>, "method": "<name>", "params": {...}}`
- Response: `{"id": <u32>, "ok": true, "result": {...}}` or
            `{"id": <u32>, "ok": false, "error": {"code": "<slug>", "message": "<text>"}}`
- Event (unsolicited, no id): `{"event": "<name>", ...}`

Requests are processed **in order on one worker thread**, except `cancel`,
`ping` and `shutdown`, which are handled immediately by the reader thread.
A response may carry a binary payload (pixels, encoded thumbnail).

Error codes: `bad_request`, `not_found`, `decode_failed`, `engine_error`,
`unsupported`, `cancelled`, `io_error`, `internal`.

## 2. Pixel payloads

A result that carries pixels has `result.image`:

```json
{"width": 1600, "height": 1067, "format": "rgba8", "color_space": "sRGB",
 "row_bytes": 6400}
```

- `rgba8`: 8-bit RGBA, display-encoded, top row first. Alpha = 255.
- `rgba16`: 16-bit LE RGBA, as the engine produced it; `color_space` names the
  engine's output space (read it, do not assume — AGENTS.md trap 28).
- `rgba16` **with** `display` (`"srgb"`, `"display-p3"` or `"prophoto"`): the
  output transform for that space, kept at 16 bits; `color_space` names it.

Display surfaces ask for `rgba8` with `display: "srgb"` (or `"display-p3"`); the
host performs the output transform so the renderer never does colour maths on
the frame. `rgba8` without `display` means `"srgb"`.

The output transform is the macOS canvas's (`Canvas/Shaders.metal`
`outputTransform`, RFC-018 §5.4) with every number from `spk_output_transform`:
the working space's curve off, the CAT02-adapted matrix, CAM16-UCS gamut
compression into the target, the target's curve on. When the target *is* the
working space the pixels pass through (the engine already compressed into it).

## 3. Methods

### Lifecycle
| method | params | result |
|---|---|---|
| `hello` | `{}` | `{protocol: 1, host_version, build_info, backend: {api: "vulkan", available, device_name, math_mode, render_core, error?}, capabilities: <spk_capabilities JSON> \| null, resources_dir, methods: [..]}` |
| `ping` | `{}` | `{}` |
| `shutdown` | `{}` | `{}` then exits 0 |
| `params_schema` | `{}` | `<spk_params_schema JSON>` |
| `print_lut_catalog` | `{}` | `<spk_print_lut_catalog JSON>` |
| `memory_report` | `{}` | `<spk_memory_report JSON>` |

### Files
| method | params | result |
|---|---|---|
| `probe` | `{path}` | `{kind: "raw"\|"tiff"\|"jpeg"\|"png"\|"pair", width, height, metadata, pair?}` (no full decode) |
| `thumbnail` | `{path, long_edge}` | `{image, source: "embedded"\|"half-size decode"\|"decode"\|"pair-source-preview", orientation_applied: true}` + rgba8 sRGB payload, **already turned to the camera's orientation** (embedded RAW preview when present, else a fast decode) |

`metadata`: `{make?, model?, lens?, iso?, shutter_s?, aperture?, focal_mm?, focal_35mm?, exposure_program?, exposure_bias_ev?, datetime_original?, orientation, as_shot?: {temperature_k, tint}}` — feeds the date back and the info readouts. `datetime_original` is ISO-8601 local time without a zone (`2026-09-14T17:03:22`), from EXIF `DateTimeOriginal`. `orientation` is the EXIF value (1–8) of the file as stored; `probe`'s `width`/`height` are **as displayed** (orientation applied), and so is every frame the host hands the engine.

White balance at decode (R2): `temperature_k` 2000–50000 and `tint` −150…150
in the Adobe DNG SDK's definition (Robertson isotherms; tint = −3000 × the
distance from the Planckian locus in CIE 1960 uv, positive is magenta) — the
scale Lightroom/ACR use. The camera side is LibRaw's XYZ→camera matrix, so
`as_shot` → `custom` with the same numbers reproduces As Shot (measured: mean
difference 0.01/255). RAW and `compatible16` only; on a raster or in
`headroom` mode it is `unsupported`. `lens_correction: true` is `unsupported`
(LibRaw carries no lens profiles).

What a file is decoded *to* (the engine develops linear ProPhoto RGB, top row first; AGENTS.md traps 11–12): RAW through LibRaw; TIFF/JPEG/PNG through their embedded matrix/TRC ICC profile (D50 colorants to XYZ to ProPhoto, as ColorSync does); without a profile, 8-bit files are sRGB and 16-bit/float TIFFs are linear ProPhoto (the macOS decoder's rule for an untagged deep TIFF). TIFF: 8/16-bit integer and 32-bit float, RGB or grey, uncompressed/LZW/deflate/PackBits, strips or tiles; not BigTIFF, CMYK or LUT-based ICC profiles (those fall back to sRGB with a log line).

### Sessions (one per open frame)
| method | params | result |
|---|---|---|
| `open` | `{path, decode?: {raw_mode?: "compatible16"\|"headroom", white_balance?: {mode: "as_shot"\|"custom", temperature_k?, tint?}, lens_correction?: false}, params?: <full or partial params JSON>}` | `{session: "<sid>", width, height, kind, metadata, params, detected_input, output_color_space, timings_ms: {decode, open}}` — any other `decode` key is `unsupported` |
| `redecode` | `{session, decode}` | as `open` (same `session` id, params kept): decode the session's file again with other decode settings. The engine session is replaced; on failure the old one is untouched (R2) |
| `close` | `{session}` | `{}` |
| `set_params` | `{session, delta: {...}}` | `{params}` (the delta is applied transactionally: on error the session is unchanged) |
| `get_params` | `{session}` | `{params}` |
| `solve` | `{session, target}` | `<spk_solve JSON>` |
| `render` | `{session, tier: "live"\|"preview"\|"full", reprint?: bool, format: "rgba8"\|"rgba16", display?: "srgb"\|"display-p3"\|"prophoto", progress_id?}` | `{image, tier, reprinted: bool, negative_was_cached: bool, engine_progress_id, timings_ms: {engine, render, transform}}` + pixels |
| `scene_latitude` | `{session, request: {...}}` | `<spk_scene_latitude JSON>` |
| `overscan_geometry` | `{session}` | `<spk_overscan_geometry JSON>` |
| `preview_stock_lut` | `{session, print_stock, tier?: "preview", format, display?}` | `{image, lut: <spk_preview_stock_lut JSON>}` + pixels; the LUT's own output space (catalog `output_color_space`) is the source of the transform |
| `cancel` | `{session, progress_id}` | `{was_running}` — handled on the reader thread: the request carrying that `progress_id` is cancelled if running (`spk_cancel`) or refused with `cancelled` when it reaches the worker |
| `progress` | `{session, engine_progress_id?}` | `<spk_progress JSON>` of the session's last render (queued behind the worker, so it reports a finished render, not one in flight; live progress is the `progress` event) |

#### Half-frame pair decoder and desktop recipes (native click acceptance pending)

`capabilities.backend.pair_decode: true` identifies the host extension. The
existing `open`/`probe`/`thumbnail` accept schema1 `.spektrapair` files from the
Mac `HalfFramePair` model. A pair references two photographs; it never rewrites
them. Each hole's decode, geometry, placement and exposure are applied to
scene-linear pixels before the ordinary spectral engine. The gap and a missing
hole are zero radiance (unexposed film), not painted black after development.
Strip spacing is1mm; bare spacing is clamped to0.5–2mm. Geometry/layout follow
`PairComposer.swift` including the source-resolution cap; composition is bounded
to1GiB of float RGB. Pair JSON is bounded to1MiB; nested pairs are refused.
The default piece has a37mm long edge (two18mm holes plus1mm gap), while
Film Format in the desktop describes one24×18mm hole, as on the Mac. The
desktop derives the whole-piece `film_format_mm` from that hole's chosen side
and length and the effective gap. The host also defaults a bare recipe to
`36 + gap` rather than24mm. Active Film Edge already fixes its physical gate
size in the original engine; that path's existing sizing is unchanged.

`open` and `redecode` return `kind: "pair"` and an additional `pair` object:
`{complete, can_export, turned, on_strip, rects: [[x,y,w,h],...], sources:
[{path,present,metadata,decode_error,exposure_ev,metered_ev,metered_for?,meter_reused,bitmap_reused},...]}`. Rectangles
are normalised, top-left, in the decoded piece before its film edge. `probe`
returns the layout from source metadata without full decodes or metering;
its `metered_ev` values are therefore zero. `thumbnail` frames the actual
camera/source previews with the same geometry; it is not a developed print.

`pair_info {session}` returns that session's latest pair object (or null for a
single photograph), including changes caused by stock/strip/meter rebuilds.
The desktop saves recipes atomically under its isolated `Pairs` store and
lists them with their recorded source folder. Ctrl+J / the filmstrip Pair
button creates a recipe from up to two picked photographs. Source sidecars
are read for initial crop/RAW white balance and are not rewritten by pair edits.
Left/right selection, replacement/clear/swap, framing, exposure/metering,
gap/turn and RAW white balance are wired; per-hole Scene Placement uses the
existing `scene_latitude.request.region` measurement. Dual-gate original
comparison samples the corresponding composed-preview rectangle per gate.

Each enabled hole is metered on its own placed picture through `spk_solve`,
then its meter+trim gain is applied before composing. The frontend saves the
returned `metered_ev`/opaque `metered_for` into the hole's original schema1
`meteredEV`/`meteredFor` fields as metadata (no undo or extra render). A key
matches source path/size/mtime, decode, owner crop/turn and meter intent;
placement, exposure/print trims and strip spacing do not re-meter, following
the Mac's stable-placement rule. Keys have a Windows decoder version prefix,
so foreign/Mac keys are remeasured. Nonfinite/out-of-range readings are not
reused. Source replacement, owner crop, decode or intent invalidates them.
Late replies merge only into still-matching holes and preserve newer edits;
the host never writes the source or pair files. `meter_reused` reports whether
the supplied reading was accepted. The strip's
`auto_exposure` is false, `overscan_pair` true and format `135_half`. Its
exposure cannot be solved as a single scene: `solve` accepts only
`filter_pack` on pair sessions. Changing strip mode, meter method or stock
recomposes transactionally. The two date strings and both Scene Latitude
parameter blocks remain ordinary engine wire fields.

All image/DI exports refuse incomplete pairs. For the edited-pixel R1 path,
`write_image` with a `.spektrapair` `source_path` also requires its live
`session`, validates completeness and copies the first present source's EXIF.
Per-hole `print`/`adjustments` requires `open.pair_presentation: "client"`.
Without that negotiation the host refuses those objects; unsupported lens
correction is always refused. `capabilities.backend.pair_presentation` is
`"client-layers-v1"`. Such sessions export ordinary images via `write_image`;
their direct `export_image` is refused so a consumer cannot silently drop grades.
Raw Cineon remains the ungraded negative, as for a single photograph.

`render_layer {session, tier, format, display, delta}` prints the same negative
with a temporary override and restores all overridden values before replying,
including on failure. Only finite `print_exposure`, `y_filter_shift`,
`m_filter_shift`, `preflash_exposure` are allowed. The host worker executes the
entire override/reprint/restore in one transaction; no queued call can observe
the temporary print. The negative cache is reused via `spk_reprint`.

The desktop follows the original Mac order: film print plus up to two own
prints, their own or inherited Layer 2 grades, then rectangle composition using
the original 1.5px `pairCoverage`. Original exposure/film simulation stays in
Vulkan. The canvas uses the existing WebGL Layer 2; exported 16-bit pixels use
its existing CPU twin before composition and final resizing. Canvas, navigator,
histogram and strip consume the composed picture, without applying the grade
again. Film/Left/Right selection, enlarger Frame/+Film scope, exposure scope,
per-hole grades/curves/wheels, undo and recipe persistence are wired. Presentation
edits do not re-decode source photos. Hole decode/geometry edits still re-open
the pair. The host keeps an LRU of up to three unexposed, ungraded float-RGB
hole bitmaps with a192MiB byte limit. Keys include source size/mtime, decode,
owner geometry, placement, target dimensions and aspect. Spacing/trim/stock
edits reuse unchanged holes; changed inputs invalidate only their hole. A hit
also supplies decoder-native size/metadata without keeping a full RAW decode.
Probe/thumbnail previews never enter this linear cache. `memory_report` adds
`pair_bitmap_cache:{entries,bytes,limit_bytes}`; `bitmap_reused` reports actual
hits. Oversized holes remain functional but can be uncached due to the limit.
Unknown recipe fields are preserved when the desktop saves known edits.
Recipe writes are drained before selection changes, native close and export;
failed saves remain retryable and prevent exporting stale pixels. No capability
here implies completed native GUI acceptance.

`reprint: true` uses `spk_reprint` (print-side edits only; API-SPEC §2); the host
falls back to `spk_render` and reports `reprinted: false` when the engine refuses.

### Export
| method | params | result |
|---|---|---|
| `export_image` | `{session, path, format: "tiff16"\|"tiff8"\|"jpeg"\|"png", quality?: 92, color_space?: "sRGB"\|"display-p3"\|"prophoto", long_edge?, overwrite?: false, progress_id?}` | `{path, width, height, bytes, color_space}` |
| `write_image` | `{path, format, quality?, color_space, width, height, source_path?, overwrite?: false}` + rgba16 LE payload (top row first, encoded in `color_space`) | `{path, width, height, bytes, color_space, exif_copied}` (R1) |
| `write_working_image` | Same as `write_image`, plus required `source_color_space`; payload is encoded in that source space after Layer 2/geometry/pair composition | Same as `write_image`, plus `source_color_space`; one engine CAT02/CAM16 conversion to the destination before encoding |

`write_working_image` is advertised in `hello.methods`. New frontends render
and grade in ProPhoto RGB for every destination, then call this method. Do not
send working pixels to an old host's `write_image`: that method still assumes
destination-encoded pixels. The source and destination use the same supported
names as `render.display`. Same-space writes preserve the input code values;
different-space writes use `OutputTransform`, including the engine-supplied
gamut mapping, rather than a separate colour library or a profile tag swap.
| `export_cube` | `{print_stock, path, overwrite?}` | `{path, size}` — the baked print LUT (`spk_print_lut_table`), domain 0..1 of normalised negative density |
| `export_di` | `{session, print_stock?, path, overwrite?}` | `{path, width, height, bytes, di: <spk_export_di JSON>}` — 16-bit TIFF of normalised negative density, no ICC (it is not a colour space) |
| `export_cineon` | `{session, path, geometry?, overwrite?, progress_id?}` | `{path, width, height, bytes, di, view_luts}` — original `spk_render_digital_intermediate` Cineon codes in ProPhoto primaries, 16-bit untagged TIFF and both shipped DI-view LUTs beside it; geometry contains only the eight `geometry_*` fields, restored after the export; Post-Dev excluded |

Cineon mode: `digital_intermediate` replaces the paper for negative film
(direct scan wins; slide film bypasses it). `render` and ordinary
`export_image` read it through the **same shipped 65³ ProPhoto DI-view LUT**
as the Mac app, including its half-float texels; the host samples it on CPU
before its existing output transform. The spectral render and Cineon encoding
remain GPU work. The view requires ProPhoto output primaries; another
`output_color_space` is explicitly rejected before a DI delta mutates the
session. An incomplete bundle discloses `digital_intermediate` as unsupported.
The raw `export_cineon` file skips this view and RGB ICC tagging. Legacy
`export_di` remains normalised density and must not back a Cineon recipe.

Files carry EXIF (TIFF Exif IFD, JPEG APP1, PNG eXIf): Make, Model,
LensModel, DateTimeOriginal, ExposureTime, FNumber, ISO, FocalLength, the
written PixelX/YDimension, Orientation 1 (the pixels are upright) and
Software. `export_image` takes them from the session's file, `write_image`
from `source_path` (rebuilt from the parsed fields, not a byte copy of the
source's EXIF; maker notes are not carried).

Files: every writer embeds an ICC profile for its `color_space` (the bundled
`io/sRGB.icc`; generated v2 matrix/TRC profiles for Display P3 and ProPhoto),
writes a hidden `.<name>.partial-<pid>-<n>` beside the destination and renames
it into place, and refuses an existing destination unless `overwrite` (§7.8
"files land whole"). PNG is 8-bit. TIFF is uncompressed, little-endian.
`long_edge` downsamples in linear light (area average) after the output
transform's matrix and gamut step, before the curve.

Events: `{"event": "progress", "session", "progress_id", "fraction", "stage"}`
(stages `render`, `transform`/`encode`, `done`; emitted only for requests that
carry a `progress_id`).

Errors: `decode_failed` (unreadable/unsupported file), `not_found` (no such
file or session), `bad_request` (a malformed parameter, or the engine's
`SPK_ERR_USER`/`INVALID_ARG` — including the refused features in
`capabilities.backend.unsupported_features`), `unsupported` (an unknown method
or decode key), `engine_error`, `cancelled`, `io_error`, `internal`.

If the engine cannot start (no Vulkan driver), the host still answers `hello`
with `backend.available: false` and `backend.error`, and every engine method
fails with `engine_error`; `probe` and `thumbnail` still work.

Lavapipe (Mesa's CPU Vulkan) works as a fallback device: the engine accepts its
unfused `fma` and, after a probe at start-up, storage buffers past its
advertised 128 MiB range; both are stated in `backend.math_mode`.

## 4. Packaging layout

The host build stages a self-contained directory per platform:

```
build/host-linux-x64/            build/host-win-x64/
  spektralab-host                  spektralab-host.exe   (static libstdc++/winpthread)
  engine/                          engine/
    <baked resources>                <baked resources>
    vulkan/*.spv                     vulkan/*.spv
    io/sRGB.icc                      io/sRGB.icc
  licenses/                        licenses/
```

`desktop/` packaging copies the matching directory into the app's
`resources/host/` (renamed to Tauri's sidecar names by the frontend's
packaging). The Tauri core (Rust) launches
`resources/host/spektralab-host[.exe] --resources resources/host/engine`.
In development, `SPEKTRALAB_HOST_DIR` overrides the directory.

### Tauri WebView bridge

The C++ stdio framing above is unchanged. Across the WebView bridge only,
binary replies/uploads larger than 8 MiB use bounded 8 MiB chunks, rather
than a single several-hundred-MB WebResource body. The Rust core owns opaque
in-process transfer IDs, validates byte counts, ordering and direction, and
releases completed, cancelled or expired transfers (1 GiB aggregate payload
quota, at most four live transfers). Pixel bytes never become JSON arrays.
An aligned received payload is shared with the uint16 export reader instead
of making an additional whole-frame copy. No colour or geometry arithmetic
lives in this transport layer. `binary_transfer.rs` and
`tauriTransport.test.ts` pin the boundaries and cleanup behavior.

### Product black-and-white profiles on Windows

The generated Vulkan resource tree also carries the original four product B&W
films and Multigrade IV RC paper plus PRODUCT_PROFILES_NOTICE.md, matching the
Mac bundle. The original28 profiles and neutral-filter database are unchanged.
The desktop sends the original silver-paper Filter2 C0/M0/Y68, disables colour
grain sublayers for monochrome stocks, multiplies the slider by the original
ownGrain values, and gates silver-paper EDR. These are caller rules from
Params.swift, not changes to the spectral/material model. The stock catalogue
separates Black & White and guards silver/colour paper compatibility. The native
BW regression covers all four films, three file formats, neutrality and the
return to the measured colour filter pack.

### Windows 1.3.3 additions

`hello.backend.working_pixel_conversion` negotiates RGBA16 ProPhoto working
pixels. `output_transform` returns the native colour matrices and Cmax data;
`convert_pixels` accepts RGBA16 working samples and chooses rgba8/rgba16 plus
colourimetric conversion when requested. `write_working_image` preserves the
working-space grade before the native destination transform. PNG supports 16-bit.
`neutral_point` samples camera RGB at source coordinates (optional measured lens
correction). Unsupported lens calibration is explicit in metadata.

`cache_info`, `cache_configure {limit_bytes}`, and `cache_clear` manage the
persistent checked linear decode cache. `memory_report`, `memory_trim` and
`memory_configure {reserve_bytes,cap_bytes,allow_over_reserve}` report real host
RAM separately from GPU pools and implement a soft cache budget, retaining live
frames. Zero cap means unlimited; this is not an OS process-memory limit.
The C ABI adds `spk_trim_memory(engine,keep_free_bytes)` to release idle GPU
allocations while retaining live and persistent resources.
